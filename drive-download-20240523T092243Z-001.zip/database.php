<?php

$conn = mysqli_connect("localhost", "root", "", "db_diyevent");

if (!$conn) {
    echo "Connection Failed";
}

$list_appoint = mysqli_query($conn, "SELECT * FROM tbl_appoinment");
$list_prod = mysqli_query($conn, "SELECT * FROM tbl_product");
$list_service = mysqli_query($conn, "SELECT * FROM tbl_service");
$list_acc= mysqli_query($conn, "SELECT * FROM tbl_users");
$list_cat = mysqli_query($conn, "SELECT * FROM tbl_category");
$tbl_message= mysqli_query($conn, "SELECT * FROM tbl_message");
$list_order= mysqli_query($conn, "SELECT * FROM tbl_order ORDER BY Order_Date ASC");
$list_customer= mysqli_query($conn, "SELECT * FROM tbl_customer");
$tbl_approve_order= mysqli_query($conn, "SELECT * FROM tbl_approve_order ORDER BY Order_Date DESC");
$tbl_done_service= mysqli_query($conn, "SELECT * FROM tbl_done_service ORDER BY Done_Date DESC");

   